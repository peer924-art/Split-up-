create extension if not exists pgcrypto;

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  expense_date date not null,
  category text not null check (category in ('Hotel','Food','Petrol','Snacks','Beverages','Other')),
  description text not null,
  amount numeric(12,2) not null check (amount > 0),
  payer text not null check (payer in ('Peer','Aasif','Faizal','Saravana')),
  shared text[] not null check (cardinality(shared) > 0),
  created_at timestamptz not null default now()
);

create index if not exists expenses_date_idx on public.expenses(expense_date);
alter table public.expenses enable row level security;
