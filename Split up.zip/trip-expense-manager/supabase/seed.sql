-- Run this AFTER schema.sql, once only. It inserts the 15 entries supplied for the trip.
-- Check the table is empty before running to avoid duplicates.
insert into public.expenses (expense_date,category,description,amount,payer,shared) values
('2026-11-15','Beverages','Beverages',2200,'Faizal',array['Aasif','Faizal','Saravana']),
('2026-11-16','Food','Morning',500,'Faizal',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-14','Food','Dinner',800,'Faizal',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-14','Hotel','Thenmal resort',4620,'Aasif',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Hotel','Advance amount',1000,'Peer',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Food','Breakfast',700,'Peer',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Food','Dinner & water bottle',1900,'Peer',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Snacks','Watermelon & glass',170,'Saravana',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Food','Lunch',1670,'Saravana',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Other','Afternoon juice (milkshake)',350,'Peer',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Hotel','Remaining amount',2500,'Saravana',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-15','Beverages','Varkala cafe',1550,'Saravana',array['Aasif','Faizal','Saravana']),
('2026-11-14','Beverages','Tenkasi purchase',750,'Saravana',array['Aasif','Faizal','Saravana']),
('2026-11-16','Food','Lunch - Saravana border',1765,'Saravana',array['Peer','Aasif','Faizal','Saravana']),
('2026-11-16','Beverages','Tenkasi bar',1500,'Saravana',array['Aasif','Faizal','Saravana']);
