import { createHmac, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
const COOKIE = "trip_session";
function sign(value: string) {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 32) throw new Error("SESSION_SECRET must be at least 32 characters.");
  return createHmac("sha256", secret).update(value).digest("hex");
}
export function makeSession() {
  const payload = Buffer.from(JSON.stringify({ ok: true, exp: Date.now() + 30*24*60*60*1000 })).toString("base64url");
  return payload + "." + sign(payload);
}
export function validSession(token?: string) {
  if (!token) return false;
  const [payload, sig] = token.split(".");
  if (!payload || !sig) return false;
  const expected = sign(payload);
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a,b)) return false;
  try { const d = JSON.parse(Buffer.from(payload,"base64url").toString()); return d.ok === true && d.exp > Date.now(); }
  catch { return false; }
}
export async function authorised() {
  const jar = await cookies();
  return validSession(jar.get(COOKIE)?.value);
}
export const cookieName = COOKIE;
