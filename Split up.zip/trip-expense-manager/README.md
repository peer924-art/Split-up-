# Shared Trip Expense Manager — Single Trip

A Next.js web application for the Tirunelveli trip (14–16 November 2026). Four members share one link and one private access code. Expenses are stored in Supabase, so changes are shared across phones and browsers.

## Included
- All **15** entries from the latest corrected expense report (not 13; the latest report contains 15).
- Members: Peer, Aasif, Faizal and Saravana.
- Shared expenses with custom participant selection (e.g. beverages split three ways).
- Add, edit, delete, filter, CSV export, live recalculation and suggested settlements.
- Single-trip edition: no multiple-trip creation screen.

## 1. Create database
1. Create a project at https://supabase.com.
2. In Supabase **SQL Editor**, run `supabase/schema.sql`.
3. Then run `supabase/seed.sql` once to load the 15 original expenses.
4. Do not run `seed.sql` again; it will create duplicates.

## 2. Configure secrets
1. Copy `.env.example` to `.env.local`.
2. Set:
   - `SUPABASE_URL` — Supabase Project URL.
   - `SUPABASE_SERVICE_ROLE_KEY` — Supabase service-role key. Keep private; never expose it in browser code or commit it.
   - `SESSION_SECRET` — random secret of at least 32 characters.
   - `TRIP_ACCESS_CODE` — the shared code the four members will use.
3. Keep `.env.local` private.

## 3. Run locally
Requires Node.js 20+.

```bash
npm install
npm run dev
```

Open http://localhost:3000. Enter the `TRIP_ACCESS_CODE`.

## 4. Deploy to get the shared link
1. Upload this project to a private GitHub repository.
2. Import that repository at https://vercel.com.
3. In Vercel Project Settings → Environment Variables, add the same four values from `.env.local`.
4. Deploy. Vercel will provide a public HTTPS URL.
5. Share that URL and the trip name/code with the four members. Everyone sees the same Supabase-backed records.

## Security notes
- Anyone with the shared code can add, edit or delete all trip expenses, matching the selected permission model.
- Share the access code only with the four members.
- The Supabase service-role key is server-only. Do not add it to any `NEXT_PUBLIC_` variable.
- This starter app does not implement per-member identities or audit history. Anyone using the group code acts as a group editor.
