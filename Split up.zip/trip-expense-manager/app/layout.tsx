import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Trip Expense Manager", description: "Shared trip expense tracking" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}
