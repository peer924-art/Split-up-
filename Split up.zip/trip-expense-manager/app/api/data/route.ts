import { NextResponse } from "next/server";
import { authorised } from "@/lib/session";
import { db } from "@/lib/db";
export async function GET(){
  try{
    if(!await authorised())return NextResponse.json({error:"Enter the trip access code."},{status:401});
    const {data,error}=await db().from("expenses").select("*").order("expense_date",{ascending:true}).order("created_at",{ascending:true});
    if(error)throw error;
    return NextResponse.json({expenses:data||[],members:["Peer","Aasif","Faizal","Saravana"],tripName:"Tirunelveli Trip · 14–16 November 2026"});
  }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Unable to load expenses."},{status:500});}
}
