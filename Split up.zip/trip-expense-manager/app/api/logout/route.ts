import { NextResponse } from "next/server";
import { cookieName } from "@/lib/session";
export async function POST(){const r=NextResponse.json({ok:true});r.cookies.set(cookieName,"",{httpOnly:true,path:"/",maxAge:0});return r;}
