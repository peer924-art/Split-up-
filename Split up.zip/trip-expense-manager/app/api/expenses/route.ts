import { NextResponse } from "next/server";
import { authorised } from "@/lib/session";
import { db } from "@/lib/db";
const cats=["Hotel","Food","Petrol","Snacks","Beverages","Other"];
export async function POST(req:Request){
 try{
  if(!await authorised())return NextResponse.json({error:"Please enter the trip code again."},{status:401});
  const x=await req.json(), amount=Number(x.amount);
  if(!x.date||!cats.includes(x.category)||!x.description?.trim()||!Number.isFinite(amount)||amount<=0||!x.payer||!Array.isArray(x.shared)||!x.shared.length)return NextResponse.json({error:"Check all expense fields."},{status:400});
  const {data,error}=await db().from("expenses").insert({expense_date:x.date,category:x.category,description:x.description.trim(),amount,payer:x.payer,shared:x.shared}).select("*").single();
  if(error)throw error;return NextResponse.json({expense:data});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Could not add expense."},{status:500});}
}
