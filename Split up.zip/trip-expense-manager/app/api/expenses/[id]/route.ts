import { NextResponse } from "next/server";
import { authorised } from "@/lib/session";
import { db } from "@/lib/db";
export async function PATCH(req:Request,ctx:{params:Promise<{id:string}>}){
 try{
  if(!await authorised())return NextResponse.json({error:"Please sign in again."},{status:401});
  const {id}=await ctx.params,x=await req.json(),amount=Number(x.amount);
  if(!x.date||!x.category||!x.description?.trim()||!Number.isFinite(amount)||amount<=0||!x.payer||!Array.isArray(x.shared)||!x.shared.length)return NextResponse.json({error:"Check all expense fields."},{status:400});
  const {data,error}=await db().from("expenses").update({expense_date:x.date,category:x.category,description:x.description.trim(),amount,payer:x.payer,shared:x.shared}).eq("id",id).select("*").single();
  if(error)throw error;return NextResponse.json({expense:data});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Update failed."},{status:500});}
}
export async function DELETE(_:Request,ctx:{params:Promise<{id:string}>}){
 try{if(!await authorised())return NextResponse.json({error:"Please sign in again."},{status:401});const {id}=await ctx.params;const {error}=await db().from("expenses").delete().eq("id",id);if(error)throw error;return NextResponse.json({ok:true});}
 catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Delete failed."},{status:500});}
}
