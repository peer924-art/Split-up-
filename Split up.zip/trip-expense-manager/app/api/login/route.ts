import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { makeSession, cookieName } from "@/lib/session";
export async function POST(req:Request) {
  try {
    const {code}=await req.json();
    const hash=process.env.TRIP_ACCESS_CODE_HASH;
    const plain=process.env.TRIP_ACCESS_CODE;
    const ok=hash ? await bcrypt.compare(String(code||""),hash) : !!plain && String(code||"")===plain;
    if(!ok) return NextResponse.json({error:"Incorrect trip access code."},{status:401});
    const res=NextResponse.json({ok:true});
    res.cookies.set(cookieName,makeSession(),{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:30*24*60*60});
    return res;
  } catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Login failed."},{status:500}); }
}
